pip install requirements.txt
